Infrastructure persistence/retrieval probe, not simulation output. A later version will contain the completed actual-host freeze and checks.
